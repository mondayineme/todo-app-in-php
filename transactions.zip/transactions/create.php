<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$amount = $profit = $depositor = $receiver = "";
$amount_err = $profit_err = $depositor_err = $receiver_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate amount
    $input_amount = trim($_POST["amount"]);
    if(empty($input_amount)){
        $amount_err = "Please enter amount.";     
    } else{
        $amount = $input_amount;
    }

    // Validate profit
    $input_profit = trim($_POST["profit"]);
    if(empty($input_profit)){
        $profit_err = "Please enter profit.";     
    } else{
        $profit = $input_profit;
    }

    // Validate depositor
    $input_depositor = trim($_POST["depositor"]);
    if(empty($input_depositor)){
        $depositor_err = "Please enter depositor's name.";
    } elseif(!filter_var($input_depositor, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $depositor_err = "Please enter a valid name.";
    } else{
        $depositor = $input_depositor;
    }
    
    // Validate receiver
    $input_receiver = trim($_POST["receiver"]);
    if(empty($input_receiver)){
        $receiver_err = "Please enter your name.";     
    } else{
        $receiver = $input_receiver;
    }
    
    
    // Check input errors before inserting in database
    if(empty($amount_err) && empty($profit_err) && empty($depositor_err) && empty($receiver_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO transactions (amount, profit, depositor, receiver) VALUES (?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $param_amount, $param_profit, $param_depositor, $param_receiver);
            
            // Set parameters
            $param_amount = $amount;
            $param_profit = $profit;
            $param_depositor = $depositor;
            $param_receiver = $receiver;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Transactions</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">GODGIFT-CONNECT</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Read Transactions</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Add Transaction</h2>
                    </div>
                    <p>Please fill this form and submit to add transactions to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="form-group <?php echo (!empty($amount_err)) ? 'has-error' : ''; ?>">
                            <label>Amount</label>
                            <input type="phone" name="amount" class="form-control" value="<?php echo $amount; ?>">
                            <span class="help-block"><?php echo $amount_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($address_err)) ? 'has-error' : ''; ?>">
                            <label>Profit</label>
                            <input type="phone" name="profit" class="form-control" value="<?php echo $profit; ?>">
                            <span class="help-block"><?php echo $profit_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($depositor_err)) ? 'has-error' : ''; ?>">
                            <label>Depositor By</label>
                            <input type="text" name="depositor" class="form-control" value="<?php echo $depositor; ?>">
                            <span class="help-block"><?php echo $depositor_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($receiver_err)) ? 'has-error' : ''; ?>">
                            <label>Admin Or Receiver</label>
                            <input type="text" name="receiver" class="form-control" value="<?php echo $receiver; ?>">
                            <span class="help-block"><?php echo $receiver_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-success" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>