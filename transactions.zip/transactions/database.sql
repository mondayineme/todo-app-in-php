CREATE TABLE transactions (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    amount VARCHAR(100) NOT NULL,
    profit VARCHAR(100) NOT NULL,
    depositor VARCHAR(100) NOT NULL,
    receiver VARCHAR(100) NOT NULL,
    date_added date NOT NULL DEFAULT current_timestamp()
);